#include "BaseSer.h"

BaseSer::BaseSer()
{

}
BaseSer::~BaseSer()
{
}

