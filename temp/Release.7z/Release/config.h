#ifndef _CONFIG_H
#define _CONFIG_H

//#ifdef WIN32
//# define _WIN32_WINNT 0x0501
//#endif // WIN32

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32))
#    define ___WINDOW___
#else
#    define ___LINUX___
#endif

#ifndef SYMBOL_EXPORT
#  ifdef ___WINDOW___
#    define SYMBOL_EXPORT __declspec(dllexport)
#  elif defined(___LINUX___)
#    define SYMBOL_EXPORT __attribute__((visibility("default")))
#  endif
#  ifndef SYMBOL_EXPORT
#    define SYMBOL_EXPORT
#  endif
#endif
#ifndef SYMBOL_IMPORT
#  if defined(___WINDOW___)
#    define SYMBOL_IMPORT __declspec(dllimport)
#  else
#    define SYMBOL_IMPORT
#  endif
#endif

#endif // _CONFIG_H