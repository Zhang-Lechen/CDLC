#include "BaseUi.h"

BaseUi::BaseUi()
{

}
BaseUi::~BaseUi()
{
}

