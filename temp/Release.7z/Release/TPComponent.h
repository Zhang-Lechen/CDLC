#pragma once
#include "Base.h"
#include <map>

 class TPComponent : public BaseSer
{
protected:
	map<string, vector<string>> m_TCInterfaceList;
	vector<string> m_TCPortList;

protected:
	void (*pTPCallback)(string &msg);
public:
	virtual const map<string, vector<string>> &GetInterfaceList() = 0;
	virtual const vector<string> &GetPortList() = 0;
	virtual void TestStart(const string &InterfaceName, vector<string> &PortList) = 0;
public:
	TPComponent(void (*pTPCallback)(string &msg))
	{
		this->pTPCallback = pTPCallback;
	}

};

